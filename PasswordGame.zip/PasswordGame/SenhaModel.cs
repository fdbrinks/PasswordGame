﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PasswordGame
{
    public class SenhaModel
    {
        public static readonly string[] CoresDisponiveis =
            { "Vermelho", "Verde", "Amarelo", "Azul", "Branco", "Preto", "Rosa", "Cinza" };
        private string[] combinacaoSecreta;
        private Random random;

        public SenhaModel()
        {
            random = new Random();
            GerarCombinacaoSecreta();
        }

        public void GerarCombinacaoSecreta()
        {
            combinacaoSecreta = CoresDisponiveis.OrderBy(x => random.Next()).Take(5).ToArray();
        }


        public string[] AvaliarPalpite(string[] palpite)
        {
            string[] resultado = new string[5];
            bool[] corCorretaPosicao = new bool[5];
            bool[] corUsadaPalpite = new bool[5];
            bool[] corUsadaSecreta = new bool[5];

            for (int i = 0; i < 5; i++)
            {
                if (palpite[i] == combinacaoSecreta[i])
                {
                    resultado[i] = "Preto";
                    corCorretaPosicao[i] = true;
                    corUsadaPalpite[i] = true;
                    corUsadaSecreta[i] = true;
                }
            }

            for (int i = 0; i < 5; i++)
            {
                if (!corCorretaPosicao[i])
                {
                    for (int j = 0; j < 5; j++)
                    {
                        if (!corUsadaSecreta[j] && palpite[i] == combinacaoSecreta[j] && !corUsadaPalpite[j])
                        {
                            resultado[j] = "Branco";
                            corUsadaSecreta[j] = true;
                            corUsadaPalpite[j] = true;
                            break;
                        }
                    }
                }
            }

            for (int i = 0; i < 5; i++)
            {
                if (resultado[i] == null)
                {
                    resultado[i] = "Vermelho";
                }
            }

            return resultado;
        }
    }
}
