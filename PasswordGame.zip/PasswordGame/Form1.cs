﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace PasswordGame
{
    public partial class Form1 : Form
    {
        private Form1Controller controller;
        private int tentativas;

        public Form1()
        {
            InitializeComponent();
            controller = new Form1Controller(this);
            tentativas = 0;

            foreach (var comboBox in GetComboBoxes())
            {
                comboBox.Items.AddRange(SenhaModel.CoresDisponiveis);
            }

            InicializarDataGrids();
        }

        private void InicializarDataGrids()
        {
            dataGridView1.ColumnCount = 5;
            dataGridView1.Columns[0].HeaderText = "Cor 1";
            dataGridView1.Columns[1].HeaderText = "Cor 2";
            dataGridView1.Columns[2].HeaderText = "Cor 3";
            dataGridView1.Columns[3].HeaderText = "Cor 4";
            dataGridView1.Columns[4].HeaderText = "Cor 5";

            dataGridView2.ColumnCount = 5;
            dataGridView2.Columns[0].HeaderText = "Posição 1";
            dataGridView2.Columns[1].HeaderText = "Posição 2";
            dataGridView2.Columns[2].HeaderText = "Posição 3";
            dataGridView2.Columns[3].HeaderText = "Posição 4";
            dataGridView2.Columns[4].HeaderText = "Posição 5";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tentativas >= 10)
            {
                MessageBox.Show("Máximo de 10 tentativas atingido. O jogo será reiniciado.");
                controller.ResetarJogo();
                return;
            }

            string[] palpite = new string[5];
            var comboBoxes = GetComboBoxes().ToArray();
            for (int i = 0; i < 5; i++)
            {
                if (comboBoxes[i].SelectedItem != null)
                {
                    palpite[i] = comboBoxes[i].SelectedItem.ToString();
                }
                else
                {
                    MessageBox.Show("Por favor, selecione todas as cores.");
                    return;
                }
            }

            controller.AvaliarPalpite(palpite);
            tentativas++;
        }

        public void LimparTentativas()
        {
            tentativas = 0;
            dataGridView1.Rows.Clear();
            dataGridView2.Rows.Clear();
            foreach (var comboBox in GetComboBoxes())
            {
                comboBox.SelectedItem = null;
            }
        }

        public void AdicionarJogada(string[] jogada)
        {
            dataGridView1.Rows.Add(jogada);
        }

        public void AdicionarResultado(string[] resultado)
        {
            int rowIndex = dataGridView2.Rows.Add();

            for (int i = 0; i < resultado.Length; i++)
            {
                Color corCelula;
                switch (resultado[i])
                {
                    case "Preto":
                        corCelula = Color.Black;
                        break;
                    case "Branco":
                        corCelula = Color.White;
                        break;
                    case "Vermelho":
                        corCelula = Color.Red;
                        break;
                    default:
                        corCelula = Color.Gray; 
                        break;
                }

                dataGridView2.Rows[rowIndex].Cells[i].Style.BackColor = corCelula;
            }
        }


        private IEnumerable<ComboBox> GetComboBoxes()
        {
            yield return comboBox1;
            yield return comboBox2;
            yield return comboBox3;
            yield return comboBox4;
            yield return comboBox5;
        }

        public void MostrarMensagem(string mensagem)
        {
            MessageBox.Show(mensagem);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
