﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PasswordGame
{
    public class Form1Controller
    {
        private SenhaModel model;
        private Form1 view;

        public Form1Controller(Form1 view)
        {
            this.view = view;
            model = new SenhaModel();
        }

        public void ResetarJogo()
        {
            model.GerarCombinacaoSecreta();
            view.LimparTentativas();
        }

        public void AvaliarPalpite(string[] palpite)
        {
            string[] resultado = model.AvaliarPalpite(palpite);
            view.AdicionarJogada(palpite);
            view.AdicionarResultado(resultado);

            if (resultado.All(r => r == "Preto"))
            {
                view.MostrarMensagem("Parabéns! Você adivinhou a combinação correta.");
                ResetarJogo();
            }
        }
    }
}
